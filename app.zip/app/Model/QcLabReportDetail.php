<?php
App::uses('AppModel', 'Model');
/**
 * QfExtFirstOffDetail Model
 *
 * @property Item $Item
 */
class QcLabReportDetail extends AppModel {


}
