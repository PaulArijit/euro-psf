<?php
App::uses('QfLoopHandleFirstOffDetailsController', 'Controller');

/**
 * QfLoopHandleFirstOffDetailsController Test Case
 *
 */
class QfLoopHandleFirstOffDetailsControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.qf_loop_handle_first_off_detail',
		'app.item',
		'app.carton_specification',
		'app.core_specification',
		'app.cylinder_specification',
		'app.flexo_plate_specification',
		'app.fusset_specification',
		'app.grommet_specification',
		'app.knife_specification',
		'app.label_specification',
		'app.product_specification',
		'app.qf_bm_quality_report_detail',
		'app.qf_ext_first_off_detail',
		'app.qf_ext_form_detail',
		'app.qf_first_off_detail',
		'app.qf_positive_release_detail',
		'app.wicket_specification',
		'app.log',
		'app.user',
		'app.log_field'
	);

/**
 * testIndex method
 *
 * @return void
 */
	public function testIndex() {
		$this->markTestIncomplete('testIndex not implemented.');
	}

/**
 * testView method
 *
 * @return void
 */
	public function testView() {
		$this->markTestIncomplete('testView not implemented.');
	}

/**
 * testAdd method
 *
 * @return void
 */
	public function testAdd() {
		$this->markTestIncomplete('testAdd not implemented.');
	}

/**
 * testEdit method
 *
 * @return void
 */
	public function testEdit() {
		$this->markTestIncomplete('testEdit not implemented.');
	}

/**
 * testDelete method
 *
 * @return void
 */
	public function testDelete() {
		$this->markTestIncomplete('testDelete not implemented.');
	}

}
