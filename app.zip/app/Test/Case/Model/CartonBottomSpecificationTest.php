<?php
App::uses('CartonBottomSpecification', 'Model');

/**
 * CartonBottomSpecification Test Case
 *
 */
class CartonBottomSpecificationTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.carton_bottom_specification',
		'app.item',
		'app.carton_specification',
		'app.core_specification',
		'app.cylinder_specification',
		'app.flexo_plate_specification',
		'app.fusset_specification',
		'app.grommet_specification',
		'app.knife_specification',
		'app.label_specification',
		'app.product_specification',
		'app.qf_bm_quality_report_detail',
		'app.qf_ext_first_off_detail',
		'app.qf_ext_form_detail',
		'app.qf_first_off_detail',
		'app.qf_positive_release_detail',
		'app.wicket_specification',
		'app.log',
		'app.user',
		'app.log_field'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->CartonBottomSpecification = ClassRegistry::init('CartonBottomSpecification');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->CartonBottomSpecification);

		parent::tearDown();
	}

}
