<?php
/**
 * KnifeBottomSpecificationFixture
 *
 */
class KnifeBottomSpecificationFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'length' => 10, 'unsigned' => true, 'key' => 'primary'),
		'item_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'length' => 10, 'unsigned' => true, 'comment' => 'foreign key to items'),
		'npi' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'ref_no' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'ref_no_two' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 62, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'knife_size' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'similar_knife' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'knife_type' => array('type' => 'integer', 'null' => false, 'default' => null, 'length' => 6, 'unsigned' => false),
		'm6_screw_holes' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'machine_type' => array('type' => 'integer', 'null' => false, 'default' => null, 'length' => 6, 'unsigned' => false),
		'base' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'punchout' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'handle_length' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'handle_width' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'amendment_note' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 225, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'remarks' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 225, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'additional_information' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 62, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id', 'unique' => 1)
		),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id' => 1,
			'item_id' => 1,
			'npi' => 'Lorem ipsum dolor sit amet',
			'ref_no' => 'Lorem ipsum dolor sit amet',
			'ref_no_two' => 'Lorem ipsum dolor sit amet',
			'knife_size' => 'Lorem ipsum dolor sit amet',
			'similar_knife' => 'Lorem ipsum dolor sit amet',
			'knife_type' => 1,
			'm6_screw_holes' => 'Lorem ipsum dolor sit amet',
			'machine_type' => 1,
			'base' => 'Lorem ipsum dolor sit amet',
			'punchout' => 'Lorem ipsum dolor sit amet',
			'handle_length' => 'Lorem ipsum dolor sit amet',
			'handle_width' => 'Lorem ipsum dolor sit amet',
			'amendment_note' => 'Lorem ipsum dolor sit amet',
			'remarks' => 'Lorem ipsum dolor sit amet',
			'additional_information' => 'Lorem ipsum dolor sit amet'
		),
	);

}
