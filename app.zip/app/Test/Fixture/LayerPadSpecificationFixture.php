<?php
/**
 * LayerPadSpecificationFixture
 *
 */
class LayerPadSpecificationFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'length' => 10, 'unsigned' => true, 'key' => 'primary'),
		'item_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'length' => 10, 'unsigned' => true, 'comment' => 'foreign key to items'),
		'npi' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'ref_no' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'size' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'board_quality' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'marking_color' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'barcode_number' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'product_gross_weight' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'film_embossed' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'ctn_marking_position' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'ctn_marking_size_width' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'ctn_marking_size_height' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'aditional_requirement' => array('type' => 'text', 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'amendment_note' => array('type' => 'text', 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'additional_information' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 62, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id', 'unique' => 1)
		),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id' => 1,
			'item_id' => 1,
			'npi' => 'Lorem ipsum dolor sit amet',
			'ref_no' => 'Lorem ipsum dolor sit amet',
			'size' => 'Lorem ipsum dolor sit amet',
			'board_quality' => 'Lorem ipsum dolor sit amet',
			'marking_color' => 'Lorem ipsum dolor sit amet',
			'barcode_number' => 'Lorem ipsum dolor sit amet',
			'product_gross_weight' => 'Lorem ipsum dolor sit amet',
			'film_embossed' => 'Lorem ipsum dolor sit amet',
			'ctn_marking_position' => 'Lorem ipsum dolor sit amet',
			'ctn_marking_size_width' => 'Lorem ipsum dolor sit amet',
			'ctn_marking_size_height' => 'Lorem ipsum dolor sit amet',
			'aditional_requirement' => 'Lorem ipsum dolor sit amet, aliquet feugiat. Convallis morbi fringilla gravida, phasellus feugiat dapibus velit nunc, pulvinar eget sollicitudin venenatis cum nullam, vivamus ut a sed, mollitia lectus. Nulla vestibulum massa neque ut et, id hendrerit sit, feugiat in taciti enim proin nibh, tempor dignissim, rhoncus duis vestibulum nunc mattis convallis.',
			'amendment_note' => 'Lorem ipsum dolor sit amet, aliquet feugiat. Convallis morbi fringilla gravida, phasellus feugiat dapibus velit nunc, pulvinar eget sollicitudin venenatis cum nullam, vivamus ut a sed, mollitia lectus. Nulla vestibulum massa neque ut et, id hendrerit sit, feugiat in taciti enim proin nibh, tempor dignissim, rhoncus duis vestibulum nunc mattis convallis.',
			'additional_information' => 'Lorem ipsum dolor sit amet'
		),
	);

}
