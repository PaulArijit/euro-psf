<?php
/**
 * QfOuterFirstOffDetailFixture
 *
 */
class QfOuterFirstOffDetailFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'length' => 10, 'unsigned' => true, 'key' => 'primary'),
		'item_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'length' => 10, 'unsigned' => true, 'comment' => 'foreign key to items'),
		'previous_product' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'cylinder_circ_specification' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'repeat_print_specification' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'gusset_specification' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'middle_specification' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'closed_width_specification' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'open_width_specification' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'film_type_specification' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'film_color_specification' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'embossed_specification' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'wt_meter_specification' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'screw_specification' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'take_up_speed_specification' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'gels_specification' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'metal_fracture_specification' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'die_line_specification' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'film_appearance_one' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'film_appearance_two' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'film_appearance_three' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'film_appearance_four' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'artwork_detail' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 62, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'pantone_one' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'pantone_two' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'pantone_three' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'pantone_four' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'pantone_five' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'pantone_six' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'viscosity_one' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'viscosity_two' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'viscosity_three' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'viscosity_four' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'viscosity_five' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'viscosity_six' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'barcode_no' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'rub_test' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'thickness' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'opacity' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'tear_strength_md' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'tear_strength_cd' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'tensile_strength_md' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'tensile_strength_cd' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'elongation_md' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'elongation_cd' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'tensile_strength_md_mml' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'tensile_strength_cd_mml' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'impact_strength_one' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'impact_strength_two' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'impact_strength_three' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'impact_strength_four' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'impact_strength_five' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'impact_strength_six' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'sample_bag_attachment' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 62, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'version' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'rev_no' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 31, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id', 'unique' => 1)
		),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id' => 1,
			'item_id' => 1,
			'previous_product' => 'Lorem ipsum dolor sit amet',
			'cylinder_circ_specification' => 'Lorem ipsum dolor sit amet',
			'repeat_print_specification' => 'Lorem ipsum dolor sit amet',
			'gusset_specification' => 'Lorem ipsum dolor sit amet',
			'middle_specification' => 'Lorem ipsum dolor sit amet',
			'closed_width_specification' => 'Lorem ipsum dolor sit amet',
			'open_width_specification' => 'Lorem ipsum dolor sit amet',
			'film_type_specification' => 'Lorem ipsum dolor sit amet',
			'film_color_specification' => 'Lorem ipsum dolor sit amet',
			'embossed_specification' => 'Lorem ipsum dolor sit amet',
			'wt_meter_specification' => 'Lorem ipsum dolor sit amet',
			'screw_specification' => 'Lorem ipsum dolor sit amet',
			'take_up_speed_specification' => 'Lorem ipsum dolor sit amet',
			'gels_specification' => 'Lorem ipsum dolor sit amet',
			'metal_fracture_specification' => 'Lorem ipsum dolor sit amet',
			'die_line_specification' => 'Lorem ipsum dolor sit amet',
			'film_appearance_one' => 'Lorem ipsum dolor sit amet',
			'film_appearance_two' => 'Lorem ipsum dolor sit amet',
			'film_appearance_three' => 'Lorem ipsum dolor sit amet',
			'film_appearance_four' => 'Lorem ipsum dolor sit amet',
			'artwork_detail' => 'Lorem ipsum dolor sit amet',
			'pantone_one' => 'Lorem ipsum dolor sit amet',
			'pantone_two' => 'Lorem ipsum dolor sit amet',
			'pantone_three' => 'Lorem ipsum dolor sit amet',
			'pantone_four' => 'Lorem ipsum dolor sit amet',
			'pantone_five' => 'Lorem ipsum dolor sit amet',
			'pantone_six' => 'Lorem ipsum dolor sit amet',
			'viscosity_one' => 'Lorem ipsum dolor sit amet',
			'viscosity_two' => 'Lorem ipsum dolor sit amet',
			'viscosity_three' => 'Lorem ipsum dolor sit amet',
			'viscosity_four' => 'Lorem ipsum dolor sit amet',
			'viscosity_five' => 'Lorem ipsum dolor sit amet',
			'viscosity_six' => 'Lorem ipsum dolor sit amet',
			'barcode_no' => 'Lorem ipsum dolor sit amet',
			'rub_test' => 'Lorem ipsum dolor sit amet',
			'thickness' => 'Lorem ipsum dolor sit amet',
			'opacity' => 'Lorem ipsum dolor sit amet',
			'tear_strength_md' => 'Lorem ipsum dolor sit amet',
			'tear_strength_cd' => 'Lorem ipsum dolor sit amet',
			'tensile_strength_md' => 'Lorem ipsum dolor sit amet',
			'tensile_strength_cd' => 'Lorem ipsum dolor sit amet',
			'elongation_md' => 'Lorem ipsum dolor sit amet',
			'elongation_cd' => 'Lorem ipsum dolor sit amet',
			'tensile_strength_md_mml' => 'Lorem ipsum dolor sit amet',
			'tensile_strength_cd_mml' => 'Lorem ipsum dolor sit amet',
			'impact_strength_one' => 'Lorem ipsum dolor sit amet',
			'impact_strength_two' => 'Lorem ipsum dolor sit amet',
			'impact_strength_three' => 'Lorem ipsum dolor sit amet',
			'impact_strength_four' => 'Lorem ipsum dolor sit amet',
			'impact_strength_five' => 'Lorem ipsum dolor sit amet',
			'impact_strength_six' => 'Lorem ipsum dolor sit amet',
			'sample_bag_attachment' => 'Lorem ipsum dolor sit amet',
			'version' => 'Lorem ipsum dolor sit amet',
			'rev_no' => 'Lorem ipsum dolor sit amet'
		),
	);

}
